import java.util.Arrays;

public class EightQueenPuzzle {

    public static void main(String[] args){

        int[][] board = new int[8][8];
        for(int[] row:board){
            Arrays.fill(row,0);
        }

        int queens = 0;
        for(int i =1; i<=4; i++){
            int a = i;
            int b = ((1+((2*i+1)%8)));
            int c = (9-i);
            int d = (8-((2*i+1)%8));
            /*System.out.print(a);
            System.out.println();
            System.out.print(b);
            System.out.println();
            System.out.print(c);
            System.out.println();
            System.out.print(d);
            System.out.println();*/

            board[a-1][b-1] =1;
            board[c-1][d-1] =1;
        }
        for(int i = 0; i<8;i++){
            System.out.println();
            for(int j = 0; j<8;j++){
                System.out.print(board[i][j]);

            }
        }
    }
}
